<?php
	header('location:gateway/action?application=login');
?>
$("#create_user").on("click",function(event){
    event.preventDefault();

    var username = $("#username").val();
    var email = $("#email").val();
    var gender = $("#gender").val();

    var validation_flag = true;

    if(username == ''){
        validation_flag = false;
        alert("Please Enter Username");
        return false;
    }

    if(email == ''){
        validation_flag = false;
        alert("Please Enter email");
        return false;
    }

    if(gender == ''){
        validation_flag = false;
        alert("Please Enter gender");
        return false;
    }

    if(validation_flag == true){

        var req_data = "username="+username+"&email="+email+"&gender="+gender;

        $.ajax(mtsoc_vars.base_url+'gateway/action?application=crud&action=create_user',
        {      
            data: req_data,
            cache: false,
        }
        ).done(function( data ) {

            try{
                var result = JSON.parse(data);
                if(result['status'] == 'success'){
                    alert(result['msg']);
                }else{
                    alert(result['msg']);
                }
            }catch(err){
                alert("Something Went Wrong");
            }
        });
    }

});

$(".delete_button").on("click",function(event){
    event.preventDefault();
    userid = $(this).data("user_id");
    alert(userid);
    if(userid != ''){
        var req_data = "userid="+userid;

        $.ajax(mtsoc_vars.base_url+'gateway/action?application=crud&action=delete_user',
        {      
            data: req_data,
            cache: false,
        }
        ).done(function( data ) {

            try{
                var result = JSON.parse(data);
                if(result['status'] == 'success'){
                    alert(result['msg']);
                    window.location.reload();
                }else{
                    alert(result['msg']);
                }
            }catch(err){
                alert("Something Went Wrong");
            }
        });
    }else{
        alert("UserId Looks Blank");
    }

});


$("#update_user").on("click",function(event){
    event.preventDefault();

    var user_id = $("#user_id").val();
    var username = $("#username").val();
    var email = $("#email").val();
    var gender = $("#gender").val();

    var validation_flag = true;

    if(user_id == ''){
        validation_flag = false;
        alert("Please Enter Username");
        return false;
    }

    if(username == ''){
        validation_flag = false;
        alert("Please Enter Username");
        return false;
    }

    if(email == ''){
        validation_flag = false;
        alert("Please Enter email");
        return false;
    }

    if(gender == ''){
        validation_flag = false;
        alert("Please Enter gender");
        return false;
    }

    if(validation_flag == true){

        var req_data = "userid="+user_id+"&username="+username+"&email="+email+"&gender="+gender;

        $.ajax(mtsoc_vars.base_url+'gateway/action?application=crud&action=update_user',
        {      
            data: req_data,
            cache: false,
        }
        ).done(function( data ) {

            try{
                var result = JSON.parse(data);
                if(result['status'] == 'success'){
                    alert(result['msg']);
                    window.location.href=mtsoc_vars.base_url+'gateway/action?application=crud&action=view_list';
                }else{
                    alert(result['msg']);
                }
            }catch(err){
                alert("Something Went Wrong");
            }
        });
    }

});
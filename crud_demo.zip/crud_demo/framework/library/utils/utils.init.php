<?php
/*
 * @company: 	Symbiotic Infotech Pvt. Ltd.
 * @copyright: 	� Symbiotic Infotech Pvt. Ltd. 2011
 *				All rights reserved.Any redistribution or reproduction of part
 * 				or all of the contents in any form is prohibited. You may not,
 * 				except with express written permission, distribute or
 * 				commercially exploit or personally use the content.
 * 				Nor may you transmit it or store it in any other media or
 * 				other form of electronic or physical retrieval system.
 *
 * @filename:	utils.init.php
 * @filetype:	PHP
 * @filedesc:	Intialize the Utility Module for Operation to be Executed.
 *
 */
require_abs ( 'framework/library/utils' );
global $utils;
$utils = new Utils ();
?>
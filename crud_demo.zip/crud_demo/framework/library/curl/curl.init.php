<?php
global $curl;
$curl = new CurlLibrary();
?>
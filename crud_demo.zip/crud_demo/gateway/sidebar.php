<header class="main-header">
	<a href="<?php echo APPLICATION_URL . 'gateway/action?application=home&action=initiate'; ?>" class="logo">
		<span class="logo-mini"><b>M</b>D</span>
		<span class="logo-lg"><b>Mtutor</b>Dashboard</span>
	</a>
	<nav class="navbar navbar-static-top">
		<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
			<span class="sr-only">Toggle navigation</span>
		</a>
		<a class="logout-btn" href="<?php echo APPLICATION_URL.'gateway/action?application=admin&action=logout' ?>"><?php echo $_SESSION['name'];?>(Logout)</a>
	</nav>
</header>
<aside class="main-sidebar">
	<section class="sidebar">
		<ul class="sidebar-menu">
			<li class="header">MENUS</li>
			<li <?php if($request['application'] == 'home' && $request['action'] == 'initiate') echo 'class="active"'; ?>>
				<a href="<?php echo APPLICATION_URL . 'gateway/action?application=home&action=initiate'; ?>">
					<span>StringProcessing</span>
				</a>
			</li>
			<li <?php if($request['application'] == 'home' && $request['action'] == 'html_elements') echo 'class="active"'; ?>>
				<a href="<?php echo APPLICATION_URL . 'gateway/action?application=home&action=html_elements'; ?>">
					<span>HTML Elements</span>
				</a>
			</li>
			<li <?php if($request['application'] == 'crud' && $request['action'] == 'home') echo 'class="active"'; ?>>
				<a href="<?php echo APPLICATION_URL . 'gateway/action?application=crud&action=home'; ?>">
					<span>Crud Home</span>
				</a>
			</li>
			<li <?php if($request['application'] == 'crud' && $request['action'] == 'view_list') echo 'class="active"'; ?>>
				<a href="<?php echo APPLICATION_URL . 'gateway/action?application=crud&action=view_list'; ?>">
					<span>Users List</span>
				</a>
			</li>
		</ul>
	</section>
</aside>

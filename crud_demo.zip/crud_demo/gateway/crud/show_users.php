<div class="content-wrapper">
	<section class="content-header">
    <div class="box box-default">
		<div class="box-body" >
            <h1>User Creation</h1>
            <div class="row" >
                <div class="col-md-12">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>User ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Gender</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if( isset($user_details) && is_array($user_details) ) {
                                foreach($user_details as $user){ ?>
                                    <tr>
                                        <td><?php echo $user['user_id']; ?></td>
                                        <td><?php echo $user['username']; ?></td>
                                        <td><?php echo $user['mail_id']; ?></td>
                                        <td><?php echo $user['gender']; ?></td>
                                        <td>
                                            <button class="btn btn-danger btn-xs delete_button" data-user_id="<?php echo $user['user_id']; ?>">Delete</button> 
                                            &nbsp; / &nbsp; 
                                            <a class="btn btn-info btn-xs" href="action?application=crud&action=edit_user&userid=<?php echo $user['user_id']; ?>">Edit</a>
                                        </td>
                                    </tr>
                            <?php  }
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
	</section>
</div>
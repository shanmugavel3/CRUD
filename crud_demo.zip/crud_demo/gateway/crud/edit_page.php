<div class="content-wrapper">
	<section class="content-header">
		<h1>User Creation</h1>
        <div class="row" >
            <form id='user_creation' name='user_creation'>
                <div class="col-md-2 ">
                    <input type="hidden" id="user_id" value="<?php echo $user_details[0]['user_id']; ?>"/>
                    <label for="username" class="control-label">UserName:</label>
                    <input type="text" id="username" class="form-control" name="username" id="username" value="<?php echo $user_details[0]['username']; ?>" style="height:28px;">
                </div>
                <div class="col-md-2 ">
                    <label for="email" class="control-label">Email:</label>
                    <input type="mail" id="email" class="form-control" name="email" id="email" value="<?php echo $user_details[0]['mail_id']; ?>" style="height:28px;">
                </div>
                <div class="col-md-2 ">
                    <label for="gender" class="control-label">Gender:</label>
                    <input type="gender" id="gender" class="form-control" name="gender" value="<?php echo $user_details[0]['gender']; ?>" style="height:28px;">
                </div>
                <div class="col-md-2 ">
                    <button class="btn btn-info btn-sm" id="update_user">Update</button>
                </div>
            </form>
        </div>
	</section>
</div>
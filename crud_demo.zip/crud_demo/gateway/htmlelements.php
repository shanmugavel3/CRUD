<div class="content-wrapper">
	<!-- <section class="content-header">
		<h1>Translator</h1>
	</section> -->
	<section class="content">
			<div class="box box-default">
				<div class="box-body" >
					<form id="tos_view_form" name="tos_view_form">
						<div class="row form-group">
							<div class="col-md-2 ">
								<label for="from" class="control-label">From Date:</label>
								<input type="text" id="from" class="form-control control-datepicker single_date" name="from" value="<?php echo date('Y-m-01'); ?>" style="height:28px;">
							</div>
							<div class="col-md-2 ">
								<label for="to" class="control-label">To Date:</label>
								<input type="text" id="to" class="form-control control-datepicker single_date" name="to" value="<?php echo date('Y-m-d'); ?>" style="height:28px;">
							</div>
							<div class="col-md-3 ">
									<label for="university" class="control-label">University:</label>
									<select name="university" id="university" class="form-control select2" placeholder = 'Select University'>
										<option value="">Select University</option>
										<?php foreach($university as $univ_val){?>
										<option value="<?php echo $univ_val['university_name']; ?>" <?php if($request['university'] == $univ_val['university_name']) echo 'selected'; ?>><?php  echo $univ_val['university_name']; ?></option>
										<?php } ?>
									</select>
							</div>
							<div class="col-md-3 ">
									<label for="subject" class="control-label">Subject:</label>
									<select id="subject" name="subject"class="form-control select2">
										<option value="">Select Subject</option>
										<?php foreach($subject as $sub_val){?>
										<option value="<?php echo $sub_val['subject_name']; ?>" <?php if($request['subject'] == $sub_val['subject_name']) echo 'selected'; ?>><?php  echo $sub_val['subject_name']; ?></option>
										<?php } ?>
									</select>
							</div>
							<div class="col-md-2 ">
									<label for="semester" class="control-label">Semester:</label>
									<select id="semester" name="semester"class="form-control select2" placeholder="Select Semester">
									<option value="">Select Semester</option>
										<option value="1" <?php if($request['semester'] == 1) echo 'selected'; ?>>Semester 1</option>
										<option value="2" <?php if($request['semester'] == 2) echo 'selected'; ?>>Semester 2</option>
										<option value="3" <?php if($request['semester'] == 3) echo 'selected'; ?>>Semester 3</option>
										<option value="4" <?php if($request['semester'] == 4) echo 'selected'; ?>>Semester 4</option>
										<option value="5" <?php if($request['semester'] == 5) echo 'selected'; ?>>Semester 5</option>
										<option value="6" <?php if($request['semester'] == 6) echo 'selected'; ?>>Semester 6</option>
										<option value="7" <?php if($request['semester'] == 7) echo 'selected'; ?>>Semester 7</option>
										<option value="8" <?php if($request['semester'] == 8) echo 'selected'; ?>>Semester 8</option>
									</select>
							</div>
							</div>
							<div class="row form-group">
							<div class="col-md-2 ">
									<label for="unit" class="control-label">Unit:</label>
									<select id="unit" name="unit"class="form-control select2">
									<option value="">Select Unit</option>
									<option value="1" <?php if($request['unit'] == 1) echo 'selected'; ?>>Unit 1</option>
									<option value="2" <?php if($request['unit'] == 2) echo 'selected'; ?>>Unit 2</option>
									<option value="3" <?php if($request['unit'] == 3) echo 'selected'; ?>>Unit 3</option>
									<option value="4" <?php if($request['unit'] == 4) echo 'selected'; ?>>Unit 4</option>
									<option value="5" <?php if($request['unit'] == 5) echo 'selected'; ?>>Unit 5</option>
									</select>
							</div>
							<div class="col-md-2 ">
									<label for="pm" class="control-label">PM:</label>
									<select id="pm" name="pm"class="form-control select2" placeholder="Select PM">
									<option value="">Select PM</option>
										<?php foreach($PM as $pm_val){?>
										<option value="<?php echo $pm_val['first_name'].'~'.$pm_val['last_name']; ?>" ><?php  echo $pm_val['first_name'].' '.$pm_val['last_name']; ?></option>
										<?php } ?>
									</select>
							</div>
							<div class="col-md-1 ">
							<input type="hidden" id="user_name" value="<?php echo $_SESSION['username']; ?>">
							<a  id="search_tos_sb" class="btn btn-info btn-md"  style="margin-left: 10px;margin-top: 24px;height:28px;">Submit</a>
							</div>
						</div>
					</form>
					<hr>
					<div id="edit_box1" >
						<table id="dtBasicExample" name="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
						<thead>
							<tr>
							  <th class="th-sm">Story Board Name
							  </th>
							  <th class="th-sm">CreatedOn
							  </th>
							  <th class="th-sm">View
							  </th>
							  <th class="th-sm">Reuse
							  </th>
							</tr>
						</thead>
						<tbody id="sakthi_tab">
						</tbody>
						</table>
					</div>
				</div>
			</div>
	</section>
</div>
			<footer class="main-footer">
				<div class="pull-right hidden-xs">
					<b>Version</b> 1.0
				</div>
				<strong>Copyright &copy; <?php echo '2016 - '.date('Y'); ?> <a href="">Mobile Tutor Pvt. Ltd</a>.</strong> All rights reserved.
			</footer>
		</div>
		<!-- Scripts -->
		<script src="<?php echo APPLICATION_URL.'resources/js/jquery.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/jquery.cookie.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/select2.full.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/bootstrap.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/app.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/moment.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/daterangepicker.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/jquery.serializejson.min.js'; ?>"></script>
		 <script src="<?php echo APPLICATION_URL.'resources/js/highstock.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/exporting.js'; ?>"></script> 
		<script src="<?php echo APPLICATION_URL.'resources/js/rgbcolor.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/canvg.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/jquery.serializejson.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/scripts.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/string_custom.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/crud_demo.js?v=1.6'; ?>"></script>

	</body>
</html>
<html>
    <head>
        <title>login</title>
        <link rel="stylesheet" href="style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

        <script src="<?php echo APPLICATION_URL.'resources/js/jquery.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/jquery.cookie.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/select2.full.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/bootstrap.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/app.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/moment.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/daterangepicker.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/jquery.serializejson.min.js'; ?>"></script>
		 <script src="<?php echo APPLICATION_URL.'resources/js/highstock.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/exporting.js'; ?>"></script> 
		<script src="<?php echo APPLICATION_URL.'resources/js/rgbcolor.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/canvg.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/jquery.serializejson.min.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/scripts.js'; ?>"></script>
		<script src="<?php echo APPLICATION_URL.'resources/js/string_custom.js'; ?>"></script>
        <script type="text/javascript"> 
			var mtsoc_vars	= {
				'base_url'		: '<?php echo APPLICATION_URL; ?>',
				'application'	: '<?php echo $request['application']; ?>'
			}
		</script>
    </head>
    <body style="background:white">
        <div class='row'>
            <div class='col-md-12'></div><br><br><br>  
        <div class='row' align="center">
            <div class='col-md-4'></div>
            <div class='col-md-4'>
                <div class='register' style="background:white">
                    <div class='month'>log-in</div><br>
                    <form>
                        <input class='roun' type="text" id="id" placeholder="ID" required><br><br>
                        <input class='roun' type="password" id="pass" placeholder="password" required><br><br>
                        <input type="submit" value="login" class=edbut onclick='insert()'><br><br>
                        <input type="button" value="forgot password?" onclick='password()'><br><br>
                        </form>
                    </div>
                </div>
            </div>
            <div class='col-md-4'></div>
        </div><br><br>
        </div>
        <div class='row' align="center">
            <div class='col-md-4'></div>
            <div class='col-md-4'>
        <div class='register' style="background:white">
            <div class='month'>Register</div><br>
                <form>
                    <label>name:</label>
                    <input class='roun' type="text" id="sname" placeholder="Enter the name" required><br><br>
                    <label>ID:</label>
                    <input class='roun' type="text" id="sid" placeholder="Enter the ID" required><br><br>
                    <label>Email:</label>
                    <input class='roun' type="text" id="semail" placeholder="Enter the Email" required><br><br>
                    <label>password:</label>
                    <input class='roun' type="password" id="spass" placeholder="password" required><br><br>
                    <input type="submit" value="register" onclick='signup()'><br><br>
                    
                </form>
            </div>
        </div></div>
            <div class='col-md-4'></div>
        </div>
        <div class="box box-default" id="response_h2" style="display:none;">
			<div class="box-body">
				<h4  ><br> <font id="response_area" color="red"></font></h4>
			</div> 
		</div>
    </body>
    <script>
        
        function insert()
        {
            event.preventDefault();
            var i=$('#id').val();
            var p=$('#pass').val();
            var id=i;
            var pass=p;
            $.ajax(mtsoc_vars.base_url+'gateway/action?application=test&action=check',   // request url
				{      
					data: {id,pass},
					cache: false,			
				}
				).done(function( data ) 
				{
					//alert(data);
					//console.log('OK');
					$('#response_h2').show();
					$('#response_area').html(data);		
				});
		    return false;
        }
        function signup()
        {
            event.preventDefault();
            var n=$('#sname').val();
            var i=$('#sid').val();
            var e=$('#semail').val();
            var p=$('#spass').val();   
            var sname=n;
            var sid=i;
            var semail=e;
            var spass=p;
            $.ajax(mtsoc_vars.base_url+'gateway/action?application=test&action=register',   // request url
			    {      
					data: {sname,sid,semail,spass},
					cache: false,						
				}
				).done(function( data ) 
				{
					//alert(data);
					//console.log('OK');
					$('#response_h2').show();
					$('#response_area').html(data)					
				});
		    return false;
        }
        function password()
        {
            event.preventDefault();
            window.location.href = mtsoc_vars.base_url+'gateway/action?application=test&action=forgot';
            return false;
        }
    </script>
</html>
<div class="content-wrapper">
	<section class="content-header">
		<h1>Strings</h1>
	</section>
	<section class="content">
		<div class="box box-default">
			<div class="box-body">
				<form>
					<input type='text' name='input' id='input'></input>
					<button onclick="postRequest();">Submit</button>
				</form>
			</div>
		</div>
		<div class="box box-default" id="response_h2" style="display:none;">
			<div class="box-body">
				<h4>String Process Response:</h4>
				<br />
				<div class="row" id="response_area" color="black"></div>
			</div> 
		</div>
	</section>
</div>
<script>
function postRequest(){
	event.preventDefault();
	var input_text=$('#input').val();
	var send='input='+input_text;
	$.ajax(mtsoc_vars.base_url+'gateway/action?application=stringops&action=string_operations',
	{      
		data: send,
		cache: false,
	}
	).done(function( data ) {

		try{
			var result = JSON.parse(data);

			if(result['status'] == 'success'){
				$('#response_h2').show();

				var html_data = "";

				$.each(result['returndata'], function (key, val) {
					html_data += "<div class='col-md-4'><h4>"+key+"&nbsp;: <b style='color:blue;'>"+val+"</b></h4> </div>";
				});

				$('#response_area').html(html_data);
			}else{
				alert(result['msg']);
				$('#response_h2').hide();
				$('#response_area').html('');
			}

		}catch(err){
			alert("Something Went Wrong");
			$('#response_h2').hide();
			$('#response_area').html('');
		}

		
	});
}
</script>